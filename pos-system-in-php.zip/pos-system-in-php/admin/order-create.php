<?php include('includes/header.php'); ?>


<!-- Modal -->
<div class="modal fade" id="addCustomerModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Add Customer</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
            <label for="">Enter Customer Name</label>
            <input type="text" class="form-control" id="c_name">
        </div>
        <div class="mb-3">
            <label for="">Enter Customer Phone no.</label>
            <input type="text" class="form-control" id="c_phone">
        </div>
        <div class="mb-3">
            <label for="">Enter Customer Email (optional)</label>
            <input type="text" class="form-control" id="c_email">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary saveCustomer">Save</button>
      </div>
    </div>
  </div>
</div>

<div class="container-fluid px-4">
    <div class="card mt-4 shadow shadow-sm">
        <div class="card_header">
            <h4>Create Order
                <a href="#" class="btn btn-danger float-end">Back</a>
            </h4>
        </div>
        <div class="card-body">

            <?php alertMessege(); ?>

            <form action="orders-code.php" method="POST">

                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label for="">Select Product</label>
                        <select name="product_id" class="form-select" id="">
                            <option value="">--Select Product--</option>
                            <?php
                            $products = getAll('products');
                            if ($products) {
                                if (mysqli_num_rows($products) > 0) {
                                    foreach ($products as $prodItem) {
                            ?>
                                        <option value="<?= $prodItem['id'] ?>">
                                            <?= $prodItem['name'] ?>
                                        </option>
                            <?php
                                    }
                                } else {
                                    echo '<option value="">No product found</option>';
                                }
                            } else {
                                echo '<option value="">Something went wrong</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-2 mb-3">
                        <label for="">Quantity</label>
                        <input type="number" name="quantity" value="1" class="form-control" />
                    </div>

                    <div class="col-md-6 mb-3 text-end">
                       
                        <button type="submit" name="addItem" class="btn btn-primary">Add Item</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- <?php
            // print_r($_SESSION['productsItems']);
            // print_r($_SESSION['productsItemsId']);
            ?> -->
</div>

<div class="card mt-3">
    <div class="card-header">
        <h4 class="mb-0">Products</h4>
    </div>
    <div class="card-body">

        <?php
        if (isset($_SESSION['productsItems'])) {
            $sessionproducts = $_SESSION['productsItems'];
            if (empty($sessionproducts)) {
                unset($_SESSION['productsItemsId']);
                unset($_SESSION['productsItems']);
            }

        ?>
            <div class="table-responsive mb-3">
                <table class="table table-striped table-bordered ">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th> Product Name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total Price</th>
                            <th>Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        foreach ($sessionproducts as $key => $item) :


                            // echo "<pre>";
                            // print_r($item);
                            // echo "</pre>";

                        ?>
                            <tr>
                                <td><?= $i++; ?></td>
                                <td><?= $item['name']; ?></td>
                                <td><?= $item['price']; ?></td>
                                <td>
                                    <div class="input-group qtyBox">
                                        <input type="hidden" value="<?= $item['product_id']; ?>" class="prodId">
                                        <button class="input-group-text decrement">-</button>
                                        <input type="text" value="<?= $item['quantity']; ?>" class="qty quantityInput" />
                                        <button class="input-group-tex increment">+</button>

                                    </div>
                                </td>
                                <td><?= number_format($item['price'] * $item['quantity'], 0); ?></td>
                                <td>
                                    <a href="order-item-delete.php?index=<?= $key ?>" class="btn btn-danger">
                                        Remove
                                    </a>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-2">
                <hr>
                <div class="row">
                    <div class="col-md-4">
                        <label for="">Select Payment Mode</label>
                        <select id="payment_mode" class="form-select">
                            <option value="">--Select Payment Method--</option>
                            <option value="Cash Payment">Cash</option>
                            <option value="Online Payment">Online Payment</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="">Enter Customer Phone Number</label>
                        <input type="number" name="phone" id="cphone" class="form-control" value="" />
                    </div>
                    <div class="col-md-4">
                        <br>
                        <button type="button" class="btn btn-warning w-100 proceedToPlace">Place Order</button>
                    </div>
                </div>
            </div>

        <?php

        } else {
            echo '<h5>No product added</h5>';
        }
        ?>
    </div>
</div>



<?php include('includes/footer.php'); ?>