<?php include('includes/header.php'); ?>

<div class="container-fluid px-4">
    <div class="card mt-4 shadow shadow-sm">
        <div class="card_header">
            <h4>Add Products
                <a href="products.php" class="btn btn-primary float-end">Back</a>
            </h4>
        </div>
        <div class="card-body">

            <?php alertMessege(); ?>

            <form action="code.php" method="POST" enctype="multipart/form-data">

                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label for="">Select Category</label>
                        <select name="category_id" id="" class="form-select">
                            <option value="">Select Category</option>
                            <?php
                            $categories = getAll('categories');
                            if($categories){
                                if(mysqli_num_rows($categories)){
                                    foreach($categories as $cateItem){

                                        echo '<option value="'.$cateItem['id'].'">'.$cateItem['name'].'</option>';
                                        
                                    }

                                }else{
                                echo '<option value="">No category found</option>';

                                }
                            }else{
                                echo '<option value="">Somthing went wrong</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="">Product Name *</label>
                        <input type="text" name="name" required class="form-control" />
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="">Description</label>
                        <textarea name="description" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="">Price *</label>
                        <input type="text" name="price" required class="form-control" />
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="">Quantity *</label>
                        <input type="text" name="quantity" required class="form-control" />
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="">Image *</label>
                        <input type="file" name="image" class="form-control" />
                    </div>
                    <div class="col-md-6">
                        <label for="">Status (Unchecked=Visible, Checked=Hidden) </label>
                        <br/>
                        <input type="checkbox" style="width: 30px;height: 30px" name="status">
                    </div>

                    <div class="col-md-6 mb-3 text-end">
                        <button type="submit" name="saveProduct" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>



<?php include('includes/footer.php'); ?>